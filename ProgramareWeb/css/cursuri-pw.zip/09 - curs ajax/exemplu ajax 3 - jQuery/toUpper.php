<?php
  $nume = $_GET['text'];
  echo strtoupper($nume);
