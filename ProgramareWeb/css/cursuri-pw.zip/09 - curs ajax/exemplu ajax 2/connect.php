<?php
mysql_connect("localhost", "root", "") or die(mysql_error());
mysql_select_db("programare_web") or die(mysql_error());
