<?php
  $nume = $_GET['tel'];
  echo strtoupper($nume);
?>
