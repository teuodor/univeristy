<?php
  $nume = $_POST['text'];
  echo strtoupper($nume);
?>
