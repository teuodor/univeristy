package curs13;

public class Record {

    String nume;
    String prenume;
    String email;
    String telefon;
    int varsta;
    String parola;
    String parola2;

    public void setNume(String nume) {
        this.nume = nume;
    }

    public void setPrenume(String prenume) {
        this.prenume = prenume;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public void setVarsta(int varsta) {
        this.varsta = varsta;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public void setParola2(String parola2) {
        this.parola2 = parola2;
    }

    public String getNume() {
        return nume;
    }

    public String getPrenume() {
        return prenume;
    }

    public String getEmail() {
        return email;
    }

    public String getTelefon() {
        return telefon;
    }

    public int getVarsta() {
        return varsta;
    }

    public String getParola() {
        return parola;
    }

    public String getParola2() {
        return parola2;
    }

}