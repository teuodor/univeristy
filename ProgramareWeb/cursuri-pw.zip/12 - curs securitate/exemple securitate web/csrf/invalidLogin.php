<html>
<head>
<script type="text/javascript">
function redirect() {
    window.location.href = 'index.php';
}
</script>
</head>
<body onLoad="setTimeout('redirect()', 5000)">
User si parola incorecte.<br/>
Veti fi redirectat la pagina de login in 5 secunde, sau click <a href="index.php">aici</a> daca browserul nu face automat redirectarea.
</body>
</html>