<h1>Autentificare administrator moderare comentarii</h1>
<form action="login.php" method="post">
Nume: <input type="text" name="user"><br>
Parola: <input type="password" name="parola"><br>
<input type="submit" value="Login">
</form>
Numele de utilizator si parola administratorului le gasiti in curs.