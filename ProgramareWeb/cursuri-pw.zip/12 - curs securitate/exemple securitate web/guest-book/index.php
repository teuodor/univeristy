<html>
<head><title>Va rog sa imi lasati un mesaj</title></head>
<body>
<form method="POST" action="trimite_mail.php">
<table>
   <tr><td>Adresa dvs de e-mail:</td><td><input type="text" name="from" style="width: 400px"/></td></tr>
<!--   <tr><td>Adresa dvs de e-mail:</td><td><textarea name="from" style="width: 400px"></textarea></td></tr> -->
   <tr><td>Mesaj:</td><td><textarea name="email" style="width: 400px "></textarea></td></tr>
   <tr><td></td><td style="text-align: right"><input type="submit" value="Trimite"/></td></tr>
</table>
</form>
</body>
</html>
