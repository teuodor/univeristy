<?php

namespace App\DataFixtures;

use App\Entity\FD;
use App\Entity\Path;
use App\Entity\Person;
use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Common\Persistence\ObjectManager;

class AppFixtures extends Fixture
{
    public function load(ObjectManager $manager)
    {
        // $product = new Product();
        // $manager->persist($product);

        $this->manager = $manager;

        $this->createPath();

        $manager->flush();
    }

    public function createPath()
    {
        $this->createTrack('oras1', 'oras2');
        $this->createTrack('oras1', 'oras4');
        $this->createTrack('oras2', 'oras3');
        $this->createTrack('oras4', 'oras5');
        $this->createTrack('oras6', 'oras7');

        $this->createPerson('Spiridon', 'Teodor', '0782346234', 'te@email.com');
        $this->createPerson('Spiridon', 'Dragos', '0782346234', 'dr@email.com');
        $this->createPerson('Solcan', 'Mihai', '0782346234', 'so@email.com');
        $this->createPerson('Stefanescu', 'Radu', '0782346234', 'st@email.com');
        $this->createPerson('Vla', 'San', '0782346234', 'vs@email.com');
        $this->createPerson('Tat', 'Chr', '0782346234', 'tc@email.com');
        $this->createPerson('Teini', 'Cozmy', '0782346234', 'cozzmy@email.com');
        $this->createPerson('Padu', 'Steven', '0782346234', 'pad@email.com');

//        $director1 = $this->createFD("director1","directory", "null", 0);
//        $director2 = $this->createFD("director2","directory", "null", 0);
//        $this->createFD("director3","directory", "null", 0);
//        $this->createFD("director4","directory", "null", $director1->getId());
//        $this->createFD("director5","directory", "null", $director1->getId());
//        $this->createFD("file1","file", "descriere de fisier", $director1->getId());
//        $this->createFD("director6","directory", "null", $director2->getId());
//        $director7 = $this->createFD("director7","directory", "null", $director2->getId());
//        $this->createFD("file1","file", "descriere de fisier", $director7->getId());
    }
    public function createTrack(string $fromCity, string $toCity) : Path
    {
        $track = new Path();
        $track->setFirstCity($fromCity);
        $track->setSecondCity($toCity);
        $this->manager->persist($track);
        return $track;
    }
    public function createPerson(string $first_name, string $last_name, string $phone_number, $email)
    {
        $person = new Person();
        $person->setFirstName($first_name);
        $person->setLastName($last_name);
        $person->setPhoneNumber($phone_number);
        $person->setEmail($email);
        $this->manager->persist($person);
        return $person;
    }
    public function createFD(string $name, string $type, string $description, int $idParent)
    {
        $fd = new FD();
        $fd->setType($type);
        $fd->getName($name);
        $fd->setDescription($description);
        $fd->setIdParent($idParent);
        $this->manager->persist($fd);
        return $fd;
    }
}
