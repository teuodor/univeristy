<?php

namespace App\Entity;

use App\Repository\NotebookRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=NotebookRepository::class)
 */
class Notebook
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $manufacturer;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $processor;

    /**
     * @ORM\Column(type="integer")
     */
    private $ram;

    /**
     * @ORM\Column(type="integer")
     */
    private $hdd;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $video_card;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getManufacturer(): ?string
    {
        return $this->manufacturer;
    }

    public function setManufacturer(string $manufacturer): self
    {
        $this->manufacturer = $manufacturer;

        return $this;
    }

    public function getProcessor(): ?string
    {
        return $this->processor;
    }

    public function setProcessor(string $processor): self
    {
        $this->processor = $processor;

        return $this;
    }

    public function getRam(): ?int
    {
        return $this->ram;
    }

    public function setRam(int $ram): self
    {
        $this->ram = $ram;

        return $this;
    }

    public function getHdd(): ?int
    {
        return $this->hdd;
    }

    public function setHdd(int $hdd): self
    {
        $this->hdd = $hdd;

        return $this;
    }

    public function getVideoCard(): ?string
    {
        return $this->video_card;
    }

    public function setVideoCard(string $video_card): self
    {
        $this->video_card = $video_card;

        return $this;
    }

    public function toSerializable(): array{
        return array("id"=>$this->getId(), "manufacturer"=>$this->getManufacturer(),
            "processor"=>$this->getProcessor(), "ram"=>$this->getRam(), "hdd"=>$this->getHdd(),
            "video_card"=>$this->getVideoCard());
    }

}
