<?php

namespace App\Entity;

use App\Repository\PathRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=PathRepository::class)
 */
class Path
{
    /**
     * @ORM\Id()
     * @ORM\GeneratedValue()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $first_city;

    /**
     * @ORM\Column(type="string", length=50)
     */
    private $second_city;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFirstCity(): ?string
    {
        return $this->first_city;
    }

    public function setFirstCity(string $first_city): self
    {
        $this->first_city = $first_city;

        return $this;
    }
    public function getSecondCity(): ?string
    {
        return $this->second_city;
    }

    public function setSecondCity(string $second_city): self
    {
        $this->second_city = $second_city;

        return $this;
    }

    public function toSerializable() {
        return array(
            'id' => $this->getId(),
            'first_city' => $this->getFirstCity(),
            'second_city' => $this->getSecondCity()
        );
    }
}
