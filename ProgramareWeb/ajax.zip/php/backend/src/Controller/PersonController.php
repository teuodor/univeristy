<?php

namespace App\Controller;

use App\Entity\Person;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\Request;

class PersonController extends AbstractController
{
    /**
     * @Route("/person/table/{page}", methods={"GET"}, name="table_page")
     * @param $page
     * @return JsonResponse
     */
    public function personTable(string $page)
    {
        $offset = ((int)$page) * 3;
        $personRepository = $this->getDoctrine()->getRepository(Person::class);
        $findAll = $personRepository->findAll();
        $persons = array_slice($findAll, $offset, 3);
        $persons_serializable = array_map(function ($person){
            return $person->toSerializable();
        }, $persons);

        return new JsonResponse($persons_serializable, 200, array('Access-Control-Allow-Origin'=> '*'));
    }

    /**
     * @Route("/person/count", methods={"GET"}, name="table_count")
     * @return JsonResponse
     */
    public function countPersons(){
        return new JsonResponse((int)(count($this->getDoctrine()->getRepository(Person::class)->findAll()) / 3), 200, array('Access-Control-Allow-Origin'=> '*'));
    }

    /**
     * @Route("/person", methods={"GET"}, name="person")
     * @return JsonResponse
     */
    public function getAll()
    {
        $personRepository = $this->getDoctrine()->getRepository(Person::class);
        $persons = $personRepository->findAll();
        $persons_serializable = array_map(function ($person){
            return $person->toSerializable();
        }, $persons);

        return new JsonResponse($persons_serializable, 200, array('Access-Control-Allow-Origin'=> '*'));
    }
    /**
     * @Route("/person/form/{id}", methods={"GET"}, name="person_form")
     * @param $id
     * @return JsonResponse
     */
    public function getById(string $id)
    {
        $personRepository = $this->getDoctrine()->getRepository(Person::class);
        $person = $personRepository->findOneBy(array('id'=>$id));
        return new JsonResponse($person->toSerializable(), 200, array('Access-Control-Allow-Origin'=> '*'));
    }

    /**
     * @Route("/person/form/update/{id}", methods={"PATCH"}, name="update")
     * @param Request $request
     * @param string $id
     * @return JsonResponse
     */
    public function update(Request $request, string $id)
    {
        $manager = $this->getDoctrine()->getManager();
        $personRepository = $this->getDoctrine()->getRepository(Person::class);
        $person = $personRepository->findOneBy(array('id'=>$id));
        $body = json_decode($request->getContent(), true);
        $person->setFirstName($body['first_name']);
        $person->setLastName($body['last_name']);
        $person->setPhoneNumber($body['phone_number']);
        $person->setEmail($body['email']);
        $manager->flush();
        return new JsonResponse("OK", 200, array('Access-Control-Allow-Origin'=> '*', 'Access-Control-Allow-Methods'=> '*'));
    }


    /**
     * @Route("/person/form/update/{id}", methods={"OPTIONS"}, name="update_options")
     * @return JsonResponse
     */
    public function update_options()
    {
        return new JsonResponse("", 200, array('Access-Control-Allow-Origin'=> '*', 'Access-Control-Allow-Methods'=> '*'));
    }
}
