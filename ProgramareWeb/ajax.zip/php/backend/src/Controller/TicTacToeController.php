<?php

namespace App\Controller;

use PhpParser\Node\Scalar\String_;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
/**
 * @Route("/tic/tac/toe", name="tic_tac_toe")
 */
class TicTacToeController extends AbstractController
{
    /**
     * @Route("/next/{id}", methods={"GET"}, name="next_move")
     * @param string $id
     * @return JsonResponse
     */
    public function getNextMove(String $id)
    {
        $positions = str_split($id);
        shuffle($positions);
        return new JsonResponse($positions[0], 200, array('Access-Control-Allow-Origin'=> '*'));
    }

    /**
     * @Route("/verif/{id}", methods={"GET"}, name="verification")
     * @param string $id
     * @return JsonResponse
     */
    public function verification(string $id)
    {
        $array = str_split($id);
        if($array[0] == $array[1] && $array[1] == $array[2] && ($array[0] == "X" || $array[0] == "0"))
            return new JsonResponse("1".$array[0], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[3] == $array[4] && $array[5] == $array[4] && ($array[3] == "X" || $array[3] == "0"))
            return new JsonResponse("1".$array[3], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[6] == $array[7] && $array[8] == $array[7] && ($array[6] == "X" || $array[6] == "0"))
            return new JsonResponse("1".$array[6], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[0] == $array[3] && $array[6] == $array[3] && ($array[0] == "X" || $array[0] == "0"))
            return new JsonResponse("1".$array[0], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[1] == $array[4] && $array[7] == $array[4] && ($array[1] == "X" || $array[1] == "0"))
            return new JsonResponse("1".$array[1], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[2] == $array[5] && $array[8] == $array[5] && ($array[2] == "X" || $array[2] == "0"))
            return new JsonResponse("1".$array[2], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[0] == $array[4] && $array[8] == $array[4] && ($array[0] == "X" || $array[0] == "0"))
            return new JsonResponse("1".$array[0], 200, array('Access-Control-Allow-Origin'=> '*'));

        if($array[2] == $array[4] && $array[6] == $array[4] && ($array[2] == "X" || $array[2] == "0"))
            return new JsonResponse("1".$array[2], 200, array('Access-Control-Allow-Origin'=> '*'));

        return new JsonResponse("0", 200, array('Access-Control-Allow-Origin'=> '*'));
    }

}
