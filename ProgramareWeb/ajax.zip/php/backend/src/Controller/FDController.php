<?php

namespace App\Controller;

use App\Entity\FD;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;

class FDController extends AbstractController
{
    /**
     * @Route("/fd/next/{id}", methods={"GET"}, name="fd_next")
     * @param $id
     * @return JsonResponse
     */
    public function next(int $id)
    {
        $fdRepository = $this->getDoctrine()->getRepository(FD::class);
        $fds = $fdRepository->findBy(array('idParent'=>$id));
        $to_return = array_map(function($fd){
            return $fd->toSerializable();
        }, $fds);
        return new JsonResponse($to_return, 200, array('Access-Control-Allow-Origin'=> '*'));
    }
}
