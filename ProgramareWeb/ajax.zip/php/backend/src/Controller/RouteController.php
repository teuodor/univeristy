<?php

namespace App\Controller;
//header('Access-Control-Allow-Origin: *');
use App\Entity\Path;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;


/**
 * @Route("/route", name="route")
 */
class RouteController extends AbstractController
{
    /**
     * @Route("", methods={"GET"}, name="list")
     * @return JsonResponse
     */
    public function listRoutes(){
        $routeRepository = $this->getDoctrine()->getRepository(Path::class);
        $routes = $routeRepository->findAll();
//        $unique_routes = array();
//        array_push($unique_routes, $routes[0]);
//        for($i = 1; $i < count($routes); $i ++)
//        {
//            $ok = false;
//            for($j = 0; $j < count($unique_routes); $j++)
//            {
//                if($unique_routes[$j]->getFirstCity() == $routes[$i]->getFirstCity())
//                {
//                    $ok = true;
//                }
//            }
//
//            if($ok == false)
//                array_push($unique_routes, $routes[$i]);
//        }

        $routes = array_map(function ($route){
            return $route->toSerializable();
        }, $routes);

        return new JsonResponse($routes, 200, array('Access-Control-Allow-Origin'=> '*'));
    }

    /**
     * @Route("/{first_city}", methods={"GET"}, name="get")
     * @param $first_city
     * @return JsonResponse
     */

    public function getCities(string $first_city)
    {
        $routeRepository = $this->getDoctrine()->getRepository(Path::class);
        $route = $routeRepository->findAll();

        if($route == null)
        {
            $response =  new JsonResponse(array('error' => true, 'message' => 'Unable to find the city'), 404, array('Access-Control-Allow-Origin'=> '*'));
            $response->setStatusCode(Response::HTTP_NOT_FOUND);
            return $response;
        }

        $routes = array();

        for($i = 0; $i < count($route); $i++)
        {

            if($route[$i]->getFirstCity() == $first_city){
                array_push($routes, $route[$i]);

            }
        }


        $routes = array_map(function ($r){
            return $r->toSerializable();
        }, $routes);

        return new JsonResponse($routes, 200, array('Access-Control-Allow-Origin'=> '*'));
    }

}

