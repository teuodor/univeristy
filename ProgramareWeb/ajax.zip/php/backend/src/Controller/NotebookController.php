<?php

namespace App\Controller;

use App\Entity\Notebook;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\Routing\Annotation\Route;
class NotebookController extends AbstractController
{
    /**
     * @Route("/notebook/filter/{id}", methods={"GET"}, name="notebook_filter")
     * @param $id
     * @return JsonResponse
     */
    public function notebook_filter(string $id)
    {
        $query_string = ltrim($id, "?");
        $attributes_values = explode("&", $query_string);
        $elements = array();
        for($i = 0; $i < count($attributes_values); $i++)
        {
            $element = explode("=", $attributes_values[$i]);
            if($element[0] == "hdd" || $element == "ram")
                $elements[$element[0]] = (int)$element[1];
            else
                $elements[$element[0]] = $element[1];
        }

        $notebooksRepository = $this->getDoctrine()->getRepository(Notebook::class);
        $to_filter = $notebooksRepository->findBy($elements);
        $to_return = array_map(function ($notebook){
            return $notebook->toSerializable();
        },$to_filter);
        return new JsonResponse($to_return, 200, array('Access-Control-Allow-Origin'=> '*'));
    }

    /**
     * @Route("/notebook", methods={"GET"}, name="find_all_notebooks")
     * @return JsonResponse
     */
    public function find_all()
    {
        $notebooksRepository = $this->getDoctrine()->getRepository(Notebook::class);
        $to_filter = $notebooksRepository->findAll();
        $to_return = array_map(function ($notebook){
            return $notebook->toSerializable();
        },$to_filter);
        return new JsonResponse($to_return, 200, array('Access-Control-Allow-Origin'=> '*'));
    }

}
