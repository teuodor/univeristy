var clicked = false
$("#first_city").on('click', 'li', function () {
    const text_loaded = $(this).html();
    console.log(text_loaded);
    var xhttp = new XMLHttpRequest();
    var jsons_byCity;
    xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            jsons_byCity = JSON.parse(xhttp.responseText)
            if(clicked)
                $("#second_city li").remove();

            for (let j = 0;j < jsons_byCity.length; j++){
                clicked = true
                $("#second_city").append("<li>" + "(" + jsons_byCity[j]['first_city'] + ", " +
                    jsons_byCity[j]['second_city'] + ")" + "</li>")
            }
        }
    };
    let url = "http://localhost:8080/route/" + text_loaded
    xhttp.open("GET",url, true);
    xhttp.send();

})
