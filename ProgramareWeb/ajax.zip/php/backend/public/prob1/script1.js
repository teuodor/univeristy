var clicked = false
$("#first_city").on('click', 'li', function () {
    const text_loaded = $(this).html();
    console.log(text_loaded);
    let url = "http://localhost:8080/route/" + text_loaded
    $.get(url, function (data) {
        if(clicked)
            $("#second_city li").remove();

        for (let j = 0;j < data.length; j++){
            clicked = true
            $("#second_city").append("<li>" + "(" + data[j]['first_city'] + ", " +
                data[j]['second_city'] + ")" + "</li>")
        }
    })
})
