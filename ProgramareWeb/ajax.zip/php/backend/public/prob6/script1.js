function click_button() {
    let not_selected = true
    let str = ""
    $($("#selects").children()).each(function(){
        if($(this).is("select")){
            if(this.options[this.selectedIndex].value !== "None"){
                not_selected = false
                str += this.classList[0] + "=" + this.options[this.selectedIndex].value
                str += "&"
            }
        }
    })
    if(not_selected){
        findAll()
    }
    else{
        str = str.substring(0, str.length - 1)
        filter(str)
    }
}

function filter(str) {
    let url = "http://localhost:8080/notebook/filter/" + str
    $.get(url, function (data) {
        $("table tr td").remove()
        let jsons = data
        for(let i  = 0; i < jsons.length; i++){
            let row = "<tr>"
            row += "<td>" + jsons[i]["manufacturer"]+"</td>"
            row += "<td>" + jsons[i]["processor"]+"</td>"
            row += "<td>" + jsons[i]["ram"]+"</td>"
            row += "<td>" + jsons[i]["hdd"]+"</td>"
            row += "<td>" + jsons[i]["video_card"]+"</td>"
            row += "</tr>"
            $("table").append(row)
        }
    })
}

function findAll(){
    let url = "http://localhost:8080/notebook"
    $.get(url, function (data) {
        let jsons = data
        $("table tr td").remove()
        for(let i  = 0; i < data.length; i++){
            let row = "<tr>"
            row += "<td>" + jsons[i]["manufacturer"]+"</td>"
            row += "<td>" + jsons[i]["processor"]+"</td>"
            row += "<td>" + jsons[i]["ram"]+"</td>"
            row += "<td>" + jsons[i]["hdd"]+"</td>"
            row += "<td>" + jsons[i]["video_card"]+"</td>"
            row += "</tr>"
            $("table").append(row)
        }
    })
}