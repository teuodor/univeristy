function click_button() {
    let not_selected = true
    let str = ""
    $($("#selects").children()).each(function(){
        if($(this).is("select")){
            if(this.options[this.selectedIndex].value !== "None"){
                not_selected = false
                str += this.classList[0] + "=" + this.options[this.selectedIndex].value
                str += "&"
            }
        }
    })
    if(not_selected){
        findAll()
    }
    else{
        str = str.substring(0, str.length - 1)
        filter(str)
    }
}

function filter(str) {
    xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200)
        {
            $("table tr td").remove()
            data = JSON.parse(this.responseText)
            for(let i  = 0; i < jsons.length; i++){
                let row = "<tr>"
                row += "<td>" + jsons[i]["manufacturer"]+"</td>"
                row += "<td>" + jsons[i]["processor"]+"</td>"
                row += "<td>" + jsons[i]["ram"]+"</td>"
                row += "<td>" + jsons[i]["hdd"]+"</td>"
                row += "<td>" + jsons[i]["video_card"]+"</td>"
                row += "</tr>"
                $("table").append(row)
            }
        }
    }
    let url = "http://localhost:8080/notebook/filter/" + str
    xhttp.open("GET", url, true)
    xhttp.send()
}

function findAll(){
    xhttp = new XMLHttpRequest()
    xhttp.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200)
        {   let tmp = 0
            $("table tr td").remove()
            data = JSON.parse(this.responseText)
            for(let i  = 0; i < jsons.length; i++){
                let row = "<tr>"
                row += "<td>" + jsons[i]["manufacturer"]+"</td>"
                row += "<td>" + jsons[i]["processor"]+"</td>"
                row += "<td>" + jsons[i]["ram"]+"</td>"
                row += "<td>" + jsons[i]["hdd"]+"</td>"
                row += "<td>" + jsons[i]["video_card"]+"</td>"
                row += "</tr>"
                $("table").append(row)
            }
        }
    }
    let url = "http://localhost:8080/notebook"
    xhttp.open("GET", url, true)
    xhttp.send()

}