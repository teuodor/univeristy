let round = 0
let player = 0
let over = false
$("table tr td").click(function () {
    if(round === 0)
    {
        if(player === 0){
            $(this).html("X")
        }
        if(player === 1){
            $(this).html("0")
        }

        if(!over)
            verif(null)

    }
})

function verif(){
    let url = "http://localhost:8080/tic/tac/toe/verif/" + positions
    $.get(url, function(data){
        let response = data
        console.log("verif raspuns" + response)
        let ok = true
        if (response[0] === "1")
        {
            if ((player === 0 && response[1] === "0") || (player === 1 && response[1] === "X"))
                ok = false
            over = true
        }

        if(!over){
            if(round === 0) {
                round = 1
                computer()
            }
            else{
                round = 0
            }
        }

        if (over) {
            if (ok)
                alert("Ai castigat")
            else
                alert("Ai pierdut")

            new_table()
        }
    let positions = ""
        $("table tr td").each(function () {
            if ($(this).html() === "")
                positions += "-"
            else
                positions += $(this).html()
        })
        console.log("verif pozitii: " + positions)

        if(!positions.includes("-")){
            alert("Egalitate");
            new_table()
        }
    })
}

function computer() {
    if (round === 1) {
        let url = "http://localhost:8080/tic/tac/toe/next/" + positions
        $.get(url, function (data) {
            let position = data
            console.log("computer position : " + position)
            let tmp = 0
            $("table tr td").each(function () {
                if (tmp === position) {
                    if (player === 0)
                        $(this).html("0")
                    else
                        $(this).html("X")
                }
                tmp += 1
            })
            console.log("computer over: " + over)
            if (!over) {
                verif(xhttp)
            }
        })
    }
}
function new_table() {
    player = Math.abs(player - 1)
    if(player === 1)
        round = 1
    else
        round = 0

    over = false

    $("table tr td").each(function(){
        $(this).html("")
    })
    if(round === 1)
        computer()

}
