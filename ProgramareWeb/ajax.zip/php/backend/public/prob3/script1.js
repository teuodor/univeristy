let clicked = false;
let data;
let current_id;
let json_person;
function initialize() {
    let url = "http://localhost:8080/person"
    $.get(url, function(data){
        for(let i = 0; i < data.length; i++){
            let row = "<li>" + data[i]['id'] + "</li>";
            $("ul").append(row);
        }
    })
}
initialize()

$("ul").on('click', 'li', function () {
    if(clicked) {
        let ok = confirm("Doriti sa se faca update-ul la persoana cu id-ul " + current_id)
        json_person['first_name'] = $("#firstname").val()
        json_person['last_name'] = $('#lastname').val();
        json_person['phone_number'] = $('#phone').val();
        json_person['email'] = $('#email').val();
        let url = "http://localhost:8080/person/form/update/" + current_id
        $.ajax({type:'PATCH',
        url:url,
        data: JSON.stringify(json_person)})
    }

    current_id = $(this).html();
    let url = "http://localhost:8080/person/form/" + current_id
    $.get(url, function (data) {
        json_person = data
        $("#firstname").val(json_person['first_name'])
        $("#lastname").val(json_person['last_name'])
        $("#phone").val(json_person['phone_number'])
        $("#email").val(json_person['email'])
        clicked = true
    })

})

function click_submit() {

}