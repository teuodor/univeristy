let clicked = false;
let data;
let current_id;
let json_person;
function initialize() {
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200){
            data = JSON.parse(xhttp.responseText)
            for(let i = 0; i < data.length; i++){
                let row = "<li>" + data[i]['id'] + "</li>";
                $("ul").append(row);
            }
        }
    }
    let url = "http://localhost:8080/person"
    xhttp.open("GET",url, true);
    xhttp.send();
}
initialize()

$("ul").on('click', 'li', function () {
    if(clicked) {
        let ok = confirm("Doriti sa se faca update-ul la persoana cu id-ul " + current_id)
        if(ok)
        {
            let xhttp2 = new XMLHttpRequest();
            xhttp2.onreadystatechange = function () {

            }
            let url = "http://localhost:8080/person/form/update/" + current_id
            xhttp2.open("PATCH", url, true)

            json_person['first_name'] = $('#firstname').val();
            json_person['last_name'] = $('#lastname').val();
            json_person['phone_number'] = $('#phone').val();
            json_person['email'] = $('#email').val();
            xhttp2.send(JSON.stringify(json_person))
        }
    }
    current_id = $(this).html();
    let xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200){
            json_person = JSON.parse(xhttp.responseText)
            $("#firstname").val(json_person['first_name'])
            $("#lastname").val(json_person['last_name'])
            $("#phone").val(json_person['phone_number'])
            $("#email").val(json_person['email'])
            clicked = true
        }
    }
    let url = "http://localhost:8080/person/form/" + current_id
    xhttp.open("GET",url, true);
    xhttp.send();
})

function click_submit() {

}