var current_page = 0
var count

function initialize() {
    let url = "http://localhost:8080/person/count"
    $.get(url, function(data){
        count = parseInt(data)
    })
    url = "http://localhost:8080/person/table/" + current_page
    $.get(url, function (data){
        for(let i = 0; i < data.length; i++){
            let row = "<tr><td>" + data[i]['first_name'] + '</td><td>' +
                data[i]['last_name'] + '</td><td>' + data[i]['phone_number'] +
                '</td><td>' + data[i]['email'] + '</td></tr>'
            $("table").append(row)
        }
    })

}
initialize()

function forward() {
    current_page += 1
    if (current_page === count)
        $("#next").prop('disabled', true)
    else
        $("#next").prop('disabled', false)
    if (current_page === 0)
        $("#back").prop('disabled', true)
    else
        $("#back").prop('disabled', false)

    let url = "http://localhost:8080/person/table/" + current_page
    $.get(url, function(data){
        $("table tr td").remove()
        for(let i = 0; i < data.length; i++){
            let row = "<tr><td>" + data[i]['first_name'] + '</td><td>' +
                data[i]['last_name'] + '</td><td>' + data[i]['phone_number'] +
                '</td><td>' + data[i]['email'] + '</td></tr>'
            $("table").append(row)
        }
    })
}


function backward() {
    current_page -= 1
    if (current_page === 0)
        $("#back").prop('disabled', true)
    else
        $("#back").prop('disabled', false)
    if (current_page === count)
        $("#next").prop('disabled', true)
    else
        $("#next").prop('disabled', false)

    let url = "http://localhost:8080/person/table/" + current_page
    $.get(url, function(data){
        $("table tr td").remove()
        for(let i = 0; i < data.length; i++){
            let row = "<tr><td>" + data[i]['first_name'] + '</td><td>' +
                data[i]['last_name'] + '</td><td>' + data[i]['phone_number'] +
                '</td><td>' + data[i]['email'] + '</td></tr>'
            $("table").append(row)
        }
    })
}