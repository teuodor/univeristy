var current_page = 0
var count

function initialize() {
    var xhttp = new XMLHttpRequest();
    xhttp.onreadystatechange = function() {
        if (this.readyState === 4 && this.status === 200) {
            count = parseInt(xhttp.responseText)
        }
    };
    let url = "http://localhost:8080/person/count"
    xhttp.open("GET",url, true);
    xhttp.send();

    let xhttp2 = new XMLHttpRequest();
    let jsons
    xhttp2.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200){
            jsons = JSON.parse(xhttp2.responseText)
            for(let i = 0; i < jsons.length; i++){
                let row = "<tr><td>" + jsons[i]['first_name'] + '</td><td>' +
                    jsons[i]['last_name'] + '</td><td>' + jsons[i]['phone_number'] +
                    '</td><td>' + jsons[i]['email'] + '</td></tr>'
                $("table").append(row)
            }
        }
    }
    url = "http://localhost:8080/person/table/" + current_page
    xhttp2.open("GET",url, true);
    xhttp2.send();
}
initialize()

function forward() {
    current_page += 1
    if (current_page === count)
        $("#next").prop('disabled', true)
    else
        $("#next").prop('disabled', false)
    if (current_page === 0)
        $("#back").prop('disabled', true)
    else
        $("#back").prop('disabled', false)

    let xhttp = new XMLHttpRequest();
    let jsons
    xhttp.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200){
            jsons = JSON.parse(xhttp.responseText)
            $("table tr td").remove()
            for(let i = 0; i < jsons.length; i++){
                let row = "<tr><td>" + jsons[i]['first_name'] + '</td><td>' +
                    jsons[i]['last_name'] + '</td><td>' + jsons[i]['phone_number'] +
                    '</td><td>' + jsons[i]['email'] + '</td></tr>'
                $("table").append(row)
            }
        }
    }
    url = "http://localhost:8080/person/table/" + current_page
    xhttp.open("GET",url, true);
    xhttp.send();
}


function backward() {
    current_page -= 1
    if (current_page === 0)
        $("#back").prop('disabled', true)
    else
        $("#back").prop('disabled', false)
    if (current_page === count)
        $("#next").prop('disabled', true)
    else
        $("#next").prop('disabled', false)

    let xhttp = new XMLHttpRequest();
    let jsons
    xhttp.onreadystatechange = function () {
        if(this.readyState === 4 && this.status === 200){
            jsons = JSON.parse(xhttp.responseText)
            $("table tr td").remove()
            for(let i = 0; i < jsons.length; i++){
                let row = "<tr><td>" + jsons[i]['first_name'] + '</td><td>' +
                    jsons[i]['last_name'] + '</td><td>' + jsons[i]['phone_number'] +
                    '</td><td>' + jsons[i]['email'] + '</td></tr>'
                $("table").append(row)
            }
        }
    }
    url = "http://localhost:8080/person/table/" + current_page
    xhttp.open("GET",url, true);
    xhttp.send();
}