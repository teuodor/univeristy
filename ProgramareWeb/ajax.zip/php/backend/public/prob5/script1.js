let xhttp = new XMLHttpRequest();
let files = []
let children_shown = []
let url = "http://localhost:8080/fd/next/0"


$.get(url, function(data){
    for(let i = 0; i < data.length; i++){
        files.push(data[i])
        children_shown.push(false)
        $("ul").append("<li><label>" + data[i]["name"] + "</label></li>")
    }
})

$("ul").on('click', 'label', function(){
    let index = 0
    let list_item = $(this).parent()
    let director_name = $(this).html()
    console.log(director_name)
    for(let i = 0; i < files.length; i++)
    {
        if(director_name === files[i]["name"]){
            index = i;
            break;
        }
    }
    if(files[index]["type"] === "directory")
    {

        if(children_shown[index] === false)
        {
            if(list_item.children().length !== 1)
            {
                list_item.children().show()
                children_shown[index] = true
            }
            else
            {
                let url = "http://localhost:8080/fd/next/" + files[index]["id"]
                $.get(url, function(data){

                    let list_child = "<ul>";
                    for(let i = 0; i < data.length; i++)
                    {
                        list_child += "<li><label>" + data[i]["name"] + "</label></li>"
                        files.push(data[i])
                        children_shown.push(false)
                    }
                    list_child += "</ul>"
                    list_item.append(list_child);
                    children_shown[index] = true

                })
            }
        }
        else
        {
            console.log(index)
            $(list_item.children()).each(function () {
                if(!$(this).is("label"))
                    $(this).hide()
            })
            children_shown[index] = false
        }
    }
    else
    {
        let name = files[index]["name"]
        let content = files[index]["description"]
        open_document(name, content)
    }
})


function open_document(name, content)
{
    let opened = window.open("")
    opened.document.write("<html><head><title>" + name + "</title></head><body>" + content +"</body></html>");
}