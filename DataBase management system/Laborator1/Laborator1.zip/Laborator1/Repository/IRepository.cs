﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laborator1.Repository
{
    interface IRepository<Id, E>
    {
        bool FindOne(Id id);

        IEnumerable<E> FindAll();

        E Save(E entity);

        E Delete(Id id);

        E Update(E entity);

    }
}
